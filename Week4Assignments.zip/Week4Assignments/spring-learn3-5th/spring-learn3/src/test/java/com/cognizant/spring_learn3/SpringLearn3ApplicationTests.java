package com.cognizant.spring_learn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
