package com.cognizant.spring_learn4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
