import React from 'react';
import Home from './Components/Home';
import About from './Components/About';
import Contact from './Components/Contact';
function App() {
  return (
    <div className="App">
      <h1 style={{ textAlign: 'center', marginTop: '30px' }}>Student Management Portal</h1>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '40px' }}>
        <Home />
        <About />
        <Contact />
      </div>
    </div>
  );
}
export default App;
