import React from 'react';
import '../Stylesheets/mystyle.css';
function CalculateScore() {
  const name = "Blessy";
  const school = "ST.Joseph's E.M.H.School";
  const total = 450;
  const goal = 500;
  const average = (total / goal) * 100;
  return (
    <div className="container">
      <h2>Student Score Report</h2>
      <p className="name"><span className="label">Name:</span> {name}</p>
      <p className="school"><span className="label">School:</span> {school}</p>
      <p className="total"><span className="label">Total:</span> {total}</p>
      <p className="goal"><span className="label">Score:</span> {goal}</p>
      <p className="average"><span className="label">Average Score:</span> {average.toFixed(2)}%</p>
    </div>
  );
}
export default CalculateScore;
